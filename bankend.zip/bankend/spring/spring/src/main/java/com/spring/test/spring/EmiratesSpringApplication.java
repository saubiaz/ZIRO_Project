package com.spring.test.spring;

import com.spring.test.controller.ToDoListController;
import com.spring.test.repository.ToDoListRepository;
import com.spring.test.repository.ToDoListRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.spring.test.controller","com.spring.test.dao"})
@EnableJpaAuditing
@EnableJpaRepositories(basePackageClasses = ToDoListRepository.class)
@EntityScan("com.spring.test.model")
public class springApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {

		SpringApplication.run(springApplication.class, args);
	}
}
