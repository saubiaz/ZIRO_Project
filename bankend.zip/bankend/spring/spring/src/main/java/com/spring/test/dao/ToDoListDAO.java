package com.spring.test.dao;

import com.spring.test.model.ToDoList;
import com.spring.test.repository.ToDoListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ToDoListDAO {

    @Autowired
   ToDoListRepository toDoListRepository;

    /*save an employee  */

    public ToDoList save(ToDoList todoList){
        return toDoListRepository.save(todoList);
    }


    //search all employees

    public List<ToDoList> findAll(){
        return toDoListRepository.findAll();
    }


    //get an employee

    public ToDoList findOne(String id){
        return toDoListRepository.findOne(id);
    }


    //delete an employee

    public void delete(ToDoList toDoList){
        toDoListRepository.delete(toDoList);
    }

}
