package com.spring.test.repository;

import com.spring.test.model.ToDoList;
import com.spring.test.model.ToDoList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ToDoListRepository extends JpaRepository<ToDoList,String> {
}
