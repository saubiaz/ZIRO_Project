package com.spring.test.controller;

import com.spring.test.dao.ToDoListDAO;
import com.spring.test.model.ToDoList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/toDoList")
@ComponentScan
@CrossOrigin(origins = "*")
public class ToDoListController {

    @Autowired
    ToDoListDAO toDoListDAO;

    //save a title
    @PostMapping("/title")
    public ToDoList createTitle(@Valid @RequestBody ToDoList toDoList){

        return toDoListDAO.save(toDoList);
    }

    //retrieve the titles
    @GetMapping("/title")
    public List<ToDoList> getAllTitles(){
        return toDoListDAO.findAll();
    }

    //get title by id
    @GetMapping("/title/{id}")
    public ResponseEntity<ToDoList> getTitleById(@PathVariable(value ="id") String id){

        ToDoList todo = toDoListDAO.findOne(id);

        if (todo==null) {
            return ResponseEntity.notFound().build();
        }
        else
            return ResponseEntity.ok().body(todo);
    }

    //update a title by emp id
    @PutMapping("/title/{id}")
    public ResponseEntity<ToDoList> updateTitle(@PathVariable(value = "id") String id,@Valid @RequestBody ToDoList toDoDetails) {

        ToDoList listUpdate = toDoListDAO.findOne(id);

        if (listUpdate==null) {
            return ResponseEntity.notFound().build();
        }
        else
            listUpdate.setTitle(toDoDetails.getTitle());
        listUpdate.setCompleted(toDoDetails.getCompleted());

        ToDoList updatToDoList=toDoListDAO.save(listUpdate);

        return ResponseEntity.ok().body(updatToDoList);
    }

    //delete a title
    @DeleteMapping("/title/{id}")
    public ResponseEntity<ToDoList> deleteTitle(@PathVariable(value = "id") String id){

        ToDoList todo = toDoListDAO.findOne(id);

        if (todo==null) {
            return ResponseEntity.notFound().build();
        }
        else
            toDoListDAO.delete(todo);
        return ResponseEntity.ok().build();
    }
}

